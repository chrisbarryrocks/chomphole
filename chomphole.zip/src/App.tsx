const App = () => {
    return (
        <div className="h-screen bg-red-500 flex items-center justify-center">
            <h1 className="text-white text-3xl font-bold">Tailwind is working</h1>
        </div>
    );
};

export default App;
